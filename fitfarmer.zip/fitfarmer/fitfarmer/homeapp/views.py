from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from .forms import NameForm


def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")


def get_details(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = NameForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            name= form.cleaned_data.get("name")

            #Write code for processing the details that are in the form and return the final value
            return render(request, 'name.html',{'name':name})

    # if a GET (or any other method) we'll create a blank form
    else:
        form = NameForm()

    return render(request, 'name.html', {'form': form})


