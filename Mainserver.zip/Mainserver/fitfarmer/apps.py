from django.apps import AppConfig


class FitfarmerConfig(AppConfig):
    name = 'fitfarmer'
